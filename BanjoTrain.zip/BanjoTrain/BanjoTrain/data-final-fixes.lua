data.raw["locomotive"]["locomotive"].working_sound =
    {
      sound =
      {
        filename = "__BanjoTrain__/sound/train.ogg",
        volume = 1.0
      }
    }